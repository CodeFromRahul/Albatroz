var screen = document.querySelector('.screen');


$('.menu').on('click', () => {
  $('.menu').toggleClass('active');
  $('.navigation').toggleClass('active');
});